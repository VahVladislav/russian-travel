# [![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Fira+Code&pause=1000&width=435&lines=%D0%9F%D1%80%D0%B8%D0%B2%D0%B5%D1%82%2C+%D0%BC%D0%B5%D0%BD%D1%8F+%D0%B7%D0%BE%D0%B2%D1%83%D1%82+%D0%92%D0%BB%D0%B0%D0%B4%D0%B8%D1%81%D0%BB%D0%B0%D0%B2!+;Hi+there%2C+I'm+Vladislav!)](https://git.io/typing-svg)
## __Путешествия по России__
### Проект представляет собой одностраничный сайт, посвященный уникальным местам для путшествий по России.
### Проводилась работа корректного отображения сайта на экранах популярных размеров, с помощью Grid элементов, а так же использования относительных размеров контейнеров, картинок и текста.
### Cсылка на GitHub Pages https://vahvladislav.github.io/russian-travel/